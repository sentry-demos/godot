/* THIS FILE IS GENERATED DO NOT EDIT */

#include <godot_cpp/godot.hpp>

static const char *_doc_data_hash = "-6563753911172845533";
static const int _doc_data_uncompressed_size = 0;
static const int _doc_data_compressed_size = 8;
static const unsigned char _doc_data_compressed[] = {
	120,
	218,
	3,
	0,
	0,
	0,
	0,
	1,
};

static godot::internal::DocDataRegistration _doc_data_registration(_doc_data_hash, _doc_data_uncompressed_size, _doc_data_compressed_size, _doc_data_compressed);

