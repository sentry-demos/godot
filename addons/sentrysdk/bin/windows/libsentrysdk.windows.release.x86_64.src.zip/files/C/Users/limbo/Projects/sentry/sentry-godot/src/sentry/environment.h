#include <godot_cpp/variant/char_string.hpp>

using namespace godot;

namespace sentry::environment {

String detect_godot_environment();

}
